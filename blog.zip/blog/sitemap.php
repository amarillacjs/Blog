<?php
header('Content-type: application/xml');
include ('conndb.php');
$query = "SELECT * FROM gits";
$result = $db -> query($query);
echo "<?xml version='1.0' encoding='UTF-8'?>"."\n";
echo "<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>"."\n";
echo " ";
while ($data = $result->fetchArray()) {
    echo "<url>";
    echo "<loc>https://neilaffy.web.id/post/".$data['url']."</loc>";
    echo "<lastmod>".$data['dates']."</lastmod>";
    echo "<priority>1.00</priority>";
    echo "</url>";
}
echo "</urlset>";
?>