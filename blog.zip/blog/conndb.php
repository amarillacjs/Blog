<?php
$dbname="nelias.db";
$db = new SQLite3($dbname);

//if (!$db) {die("db not created .... ");} else {echo "create database successfully";}

//create table in sqlite database
$query = "CREATE TABLE IF NOT EXISTS gits(users_id integer primary key, judul text,url text, keyword text, dates text, deskripsi text, artikel text)";
$db->exec($query);
?>
