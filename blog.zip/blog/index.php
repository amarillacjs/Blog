<?php
session_start();
include 'conndb.php';
$query = "SELECT * FROM gits";
$result = $db -> query($query);
echo $_SESSION['start'];
unset($_SESSION['start']);
unset($_SESSION['no-login']);
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Neilaffy</title>
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>
<body class="max">
    <nav class="bg-light">
        <div class="navbar">
            <a class="logo">
                <h1>Neilaffy</h1>
            </a>
        </div>
    </nav>
    <section class="box">
        <?php
        while ($row = $result->fetchArray()) {
            ?>
            <div class="card">
                <h2><?php echo $row['judul']; ?></h2>
                <p class="py-1">
                    <?php echo $row['deskripsi']; ?>
                </p>
                <div style="margin-bottom:10px;">
                    <?php echo $row['dates']." ".$row['keyword']; ?>
                </div>
                <a class="" href="#">Readmore</a>
            </div>
            <?php
        } ?>
    </section>
    <footer>
        @2024 - 2025
    </footer>
</body>
</html>