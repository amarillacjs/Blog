<?php
session_start();
include 'conndb.php';
include "Parsedown.php";
if ($_SESSION['no-login'] == "amarillacss") {
    date_default_timezone_set("Asia/Jakarta");
    if (isset($_POST['simpan'])) {
        
        $judul = $_POST['judul'];
        $url = $_POST['url'];
        $keyword = $_POST['keyword'];
        $dates = $_POST['dates'];
        $deskripsi = $_POST['deskripsi'];
        $post = $_POST['artikel'];
        $post_url = preg_replace('/[^a-z0-9-]+/', '-', trim(strtolower($url)));   
        $query = "INSERT INTO gits(judul,url,keyword,dates,deskripsi,artikel) VALUES('$judul','$post_url','$keyword','$dates','$deskripsi','$post');";
        if ($db->exec($query)) {
            $_SESSION['start'] = "Success";
            header("Location: index.php");
        } else {
            echo "error with the query";
        }
    }
} else {
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=0.4">
    <title>Neilaffy</title>
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>
<body class="max">
    <nav class="bg-light">
        <div class="navbar">
            <a class="logo">
                <h1>Neilaffy</h1>
            </a>
            <ul>
                <li>
                    <a class="" href="index.php">Home</a>
                </li>
                <li>
                    <a class="" href="about.php">About Us</a>
                </li>
                <li>
                    <a class="" href="contact.php">Contact</a>
                </li>
                <li>
                    <a class="" href="sitemap.xml">Sitemap</a>
                </li>
            </ul>
        </div>
    </nav>
    <section class="tils">
        <h2>Create</h2>
    </section>
    <form class="box" action="" method="post">
        <div class="card">
            <div>
                <input type="text" name="judul" class="control" placeholder="Judul" />
            </div>
            <div>
                <input type="text" name="url" class="control" placeholder="Url Judul" />
            </div>
            <div>
                <input type="text" name="keyword" class="control" placeholder="Keyword" />
            </div>
            <div>
                <input type="text" name="dates" class="control" value="<?php echo date("d-m-Y H:i:s"); ?>" />
            </div>
        </div>
        <div class="card">
            <div>
                <textarea name="deskripsi" id=rows="8" cols="40" class="control" placeholder="deskripsi"></textarea>
            </div>
            <div>
                <textarea name="artikel" rows="50" cols="40" class="control" placeholder="Artikel"></textarea>
            </div>
        </div>
        <button type="submit" name="simpan" class="btn">Simpan</button>
    </form>
    <footer>
        @2024 - 2025
    </footer>
</body>
</html>