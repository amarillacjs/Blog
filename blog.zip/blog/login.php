<?php
    if(isset($_POST['btn'])){
        session_start();
        $_SESSION['no-login'] = $_POST['login'];
        header("Location: buat.php");
    }
    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title></title>
    </head>
    <body>
        <form action="" method="post" accept-charset="utf-8">
            <input type="text" name="login" id="" placeholder="Login" />
            <button type="submit" name="btn">Login</button>
        </form>
    </body>
</html>