<?php
include 'conndb.php';
$post_url = $_GET["post_url"];
$query = "SELECT * FROM gits WHERE url =".$post_url;
$result = $db -> query($query);
include 'Parsedown.php';
$Parsedown = new Parsedown();

?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=0.4">
    <title>Neilaffy</title>
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>
<body class="max">
    <nav class="bg-light">
        <div class="navbar">
            <a class="logo">
                <h1>Neilaffy</h1>
            </a>
            <ul>
                <li>
                    <a class="" href="index.php">Home</a>
                </li>
                <li>
                    <a class="" href="about.php">About Us</a>
                </li>
                <li>
                    <a class="" href="contact.php">Contact</a>
                </li>
                <li>
                    <a class="" href="sitemap.xml">Sitemap</a>
                </li>
            </ul>
        </div>
    </nav>
    <section class="posts">

        <div>
            <?php while ($row = $result->fetchArray()) {
                ?>
                <h1><?php echo $row['judul']; ?></h1>
                <div>
                    <?php $md = $Parsedown->text($row['artikel']);
                    echo $md; ?>
                </div>
                <div>
                    <?php echo $row['dates']." ".$row['keyword'] ?>
                </div>

                <?php
            } ?>
        </div>
        <a class="" href="#">Readmore</a>
    </section>
    <footer>
        @2024 - 2025
    </footer>
</body>
</html>